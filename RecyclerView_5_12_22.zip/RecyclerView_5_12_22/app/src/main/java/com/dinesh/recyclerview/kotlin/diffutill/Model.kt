package com.dinesh.recyclerview.kotlin.diffutill



data class Users(val id: Int, val name: String, val address: String, val image: String)
