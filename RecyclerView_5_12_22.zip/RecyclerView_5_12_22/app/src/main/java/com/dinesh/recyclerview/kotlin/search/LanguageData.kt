package com.dinesh.recyclerview.kotlin.search


data class LanguageData(val title : String , val logo : Int)
