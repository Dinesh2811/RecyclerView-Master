package com.dinesh.recyclerview.rv;

public class x {
    /*  rvList

    RvMain
    List<RvModel> rvModelList = new ArrayList<>();
    RvAdapter rvAdapter;
    RecyclerView recyclerView;


    RvAdapter
    List<RvModel> rvModelList = new ArrayList<>();
    RvInterface rvInterface;


    RvModel
    RvInterface


rv_main
rv_list

     */

}

//
////--------------------------------------- RvMain.java ---------------------------------------//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.DividerItemDecoration;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.ArrayList;
//import java.util.List;
////--------------------------------------- RvMain.java ---------------------------------------//
//
////--------------------------------------- RvAdapter.java ---------------------------------------//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.ArrayList;
//import java.util.List;
////--------------------------------------- RvAdapter.java ---------------------------------------//


/**
 * test_rv_main.xml
 * <p>
 * <p>
 * <p>
 * test_rv_list.xml
 * <p>
 * <p>
 * <p>
 * test_new_layout.xml
 */

/* ----------------------------------------    test_rv_main.xml    ----------------------------------------

<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/test_recyclerView"
        android:layout_width="0dp"
        android:layout_height="0dp"
        android:layout_marginStart="1dp"
        android:layout_marginTop="1dp"
        android:layout_marginEnd="1dp"
        android:layout_marginBottom="1dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>


----------------------------------------------------------------------------------------------------*/


/**
 *
 * test_rv_list.xml
 *
 */

/* ----------------------------------------    test_rv_list.xml    ----------------------------------------

<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content">


    <TextView
        android:id="@+id/test_textView1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginStart="8dp"
        android:layout_marginTop="8dp"
        android:layout_marginBottom="8dp"
        android:text="TextView"
        android:textSize="16sp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <TextView
        android:id="@+id/test_textView2"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginStart="8dp"
        android:layout_marginEnd="8dp"
        android:text="TextView"
        android:textSize="16sp"
        app:layout_constraintBottom_toBottomOf="@+id/test_textView1"
        app:layout_constraintStart_toEndOf="@+id/test_textView1" />

    <TextView
        android:id="@+id/test_textView3"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginStart="8dp"
        android:layout_marginEnd="8dp"
        android:text="TextView"
        android:textSize="16sp"
        app:layout_constraintBottom_toBottomOf="@+id/test_textView1"
        app:layout_constraintStart_toEndOf="@+id/test_textView2" />

    <TextView
        android:id="@+id/test_textView4"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginStart="8dp"
        android:layout_marginEnd="8dp"
        android:text="TextView"
        android:textSize="16sp"
        app:layout_constraintBottom_toBottomOf="@+id/test_textView1"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toEndOf="@+id/test_textView3" />


</androidx.constraintlayout.widget.ConstraintLayout>



----------------------------------------------------------------------------------------------------*/


/**
 *
 * test_new_layout.xml
 *
 */

/* ----------------------------------------    test_new_layout.xml    ----------------------------------------

<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <TextView
        android:id="@+id/test_textView5"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="TextView"
        app:layout_constraintBottom_toTopOf="@+id/test_textView6"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintHorizontal_bias="0.5"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <TextView
        android:id="@+id/test_textView6"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="TextView"
        app:layout_constraintBottom_toTopOf="@+id/test_textView7"
        app:layout_constraintStart_toStartOf="@+id/test_textView5"
        app:layout_constraintTop_toBottomOf="@+id/test_textView5" />

    <TextView
        android:id="@+id/test_textView7"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="TextView"
        app:layout_constraintBottom_toTopOf="@+id/test_textView8"
        app:layout_constraintStart_toStartOf="@+id/test_textView6"
        app:layout_constraintTop_toBottomOf="@+id/test_textView6" />

    <TextView
        android:id="@+id/test_textView8"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="TextView"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="@+id/test_textView7"
        app:layout_constraintTop_toBottomOf="@+id/test_textView7" />

</androidx.constraintlayout.widget.ConstraintLayout>



----------------------------------------------------------------------------------------------------*/