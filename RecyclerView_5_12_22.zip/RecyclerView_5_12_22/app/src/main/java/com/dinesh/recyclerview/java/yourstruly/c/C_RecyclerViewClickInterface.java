package com.dinesh.recyclerview.java.yourstruly.c;
public interface C_RecyclerViewClickInterface {
    void onItemClick(int position);
    void onLongItemClick(int position);
}