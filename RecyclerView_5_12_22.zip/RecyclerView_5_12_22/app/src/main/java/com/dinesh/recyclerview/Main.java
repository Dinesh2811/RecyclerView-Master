package com.dinesh.recyclerview;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.dinesh.recyclerview.java.yourstruly.h.RvMain;


public class Main extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        startActivity(new Intent(this, MainActivity.class));
//        startActivity(new Intent(this, MainActivity.class));
//        startActivity(new Intent(this, N_MainActivity.class));
//        startActivity(new Intent(this, J_MainActivity.class));
//        startActivity(new Intent(this, I_MainActivity.class));
        startActivity(new Intent(this, RvMain.class));
//        startActivity(new Intent(this, G_MainActivity.class));
//        startActivity(new Intent(this, F_MainActivity.class));
//        startActivity(new Intent(this, E_MainActivity.class));
//        startActivity(new Intent(this, J_SG_MainActivity.class));
//        startActivity(new Intent(this, SG_MainActivity.class));
//        startActivity(new Intent(this, C_MainActivity.class));
//        startActivity(new Intent(this, RvMain.class));


//        startActivity(new Intent(this, SG_MainActivity.class));
//        startActivity(new Intent(this, RvMain.class));
    }
}


/*

a -> Rv without Model
b -> Refresh Rv without Model



 */


/*


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;


 */
