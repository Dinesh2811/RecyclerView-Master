package com.dinesh.recyclerview.java.yourstruly.n_databinding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;

import android.os.Bundle;


import com.dinesh.recyclerview.databinding.NActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class N_MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);

//        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        NActivityMainBinding activityMainBinding = NActivityMainBinding.inflate(getLayoutInflater());
        setContentView(activityMainBinding.getRoot());

        N_UserRecyclerAdapter NUserRecyclerAdapter = new N_UserRecyclerAdapter(getUserList());
        activityMainBinding.recyclerView.setAdapter(NUserRecyclerAdapter);
        activityMainBinding.recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

    }

    private List<N_User> getUserList() {
        List<N_User> NUserList = new ArrayList<>();
        NUserList.add(new N_User("Jhon Doe", 70, true, "https://picsum.photos/id/237/200"));
        NUserList.add(new N_User("Charles Dickens", 70, true, "https://picsum.photos/id/238/200"));
        NUserList.add(new N_User("Harry Potter", 70, false, "https://picsum.photos/id/239/200"));
        NUserList.add(new N_User("Jessica Simpson", 70, true, "https://picsum.photos/id/240/200"));
        NUserList.add(new N_User("Paul Addams", 70, false, "https://picsum.photos/id/241/200"));
        return NUserList;
    }
}