package com.dinesh.recyclerview.rv;

import android.view.View;

/**
 * RvInterface
 */


public interface RvInterface {
    void onItemClick(View view, int position);
}
