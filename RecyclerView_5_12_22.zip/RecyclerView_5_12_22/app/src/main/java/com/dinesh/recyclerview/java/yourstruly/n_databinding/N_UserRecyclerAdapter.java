package com.dinesh.recyclerview.java.yourstruly.n_databinding;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.dinesh.recyclerview.databinding.NProductRowBinding;

import java.util.List;

public class N_UserRecyclerAdapter extends RecyclerView.Adapter<N_UserRecyclerAdapter.UserViewHolder> {

    private static final String TAG = "UserRecyclerAdapter";

    List<N_User> NUserList;

    public N_UserRecyclerAdapter(List<N_User> NUserList) {
        this.NUserList = NUserList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        NProductRowBinding productRowBinding = NProductRowBinding.inflate(layoutInflater, parent, false);
        return new UserViewHolder(productRowBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        final N_User NUser = NUserList.get(position);
        holder.productRowBinding.setNUser(NUser);
        holder.productRowBinding.executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return NUserList.size();
    }

    class UserViewHolder extends RecyclerView.ViewHolder {

        NProductRowBinding productRowBinding;

        public UserViewHolder(@NonNull NProductRowBinding productRowBinding) {
            super(productRowBinding.getRoot());
            this.productRowBinding = productRowBinding;

            productRowBinding.activeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "onClick: " + NUserList.get(getAdapterPosition()));
                }
            });
        }
    }
}