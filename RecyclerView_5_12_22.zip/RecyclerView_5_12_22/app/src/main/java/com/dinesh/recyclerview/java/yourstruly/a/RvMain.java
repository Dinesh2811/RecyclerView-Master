package com.dinesh.recyclerview.java.yourstruly.a;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dinesh.recyclerview.R;

import java.util.ArrayList;
import java.util.List;

public class RvMain extends AppCompatActivity {


    List<String> rvList = new ArrayList<>();
    RvAdapter rvAdapter;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.x_rv_main);

        recyclerView = findViewById(R.id.recyclerView);
        rvAdapter = new RvAdapter(rvList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recyclerView.setAdapter(rvAdapter);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);


        rvList.add("Iron Man");
        rvList.add("The Incredible Hulk");
        rvList.add("Iron Man 2");
        rvList.add("Thor");
        rvList.add("Captain America: The First Avenger");
        rvList.add("The Avengers");
        rvList.add("Iron Man 3");
        rvList.add("Thor: The Dark World");
        rvList.add("Captain America: The Winter Soldier");
        rvList.add("Guardians of the Galaxy");
        rvList.add("Avengers: Age of Ultron");
        rvList.add("Ant-Man");
        rvList.add("Captain America: Civil War");
        rvList.add("Doctor Strange");
        rvList.add("Guardians of the Galaxy Vol. 2");
        rvList.add("Spider-Man: Homecoming");
        rvList.add("Thor: Ragnarok");
        rvList.add("Black Panther");
        rvList.add("Avengers: Infinity War");
        rvList.add("Ant-Man and the Wasp");
        rvList.add("Captain Marvel");
        rvList.add("Avengers: Endgame");
        rvList.add("Spider-Man: Far From Home");
    }
}