package com.dinesh.recyclerview.java.yourstruly.i;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.dinesh.recyclerview.databinding.IActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class I_MainActivity extends AppCompatActivity {

    IActivityMainBinding activityMainBinding;
    I_RecyclerAdapter IRecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = IActivityMainBinding.inflate(getLayoutInflater());
        View rootView = activityMainBinding.getRoot();
        setContentView(rootView);

        IRecyclerAdapter = new I_RecyclerAdapter();
        activityMainBinding.recyclerView.setAdapter(IRecyclerAdapter);

        List<String> list = new ArrayList<>();
        list.add("Iron man");
        list.add("Iron man 2");
        list.add("Iron man 3");
        list.add("Captain America: The First Avenger");
        list.add("Captain America: The Winter Soldier");
        list.add("Captain America: Civil War");
        IRecyclerAdapter.updateList(list);
    }

}