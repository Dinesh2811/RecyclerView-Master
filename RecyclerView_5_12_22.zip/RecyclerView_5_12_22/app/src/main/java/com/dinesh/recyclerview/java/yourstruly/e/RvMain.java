package com.dinesh.recyclerview.java.yourstruly.e;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.dinesh.recyclerview.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RvMain extends AppCompatActivity {
//
//    RecyclerView recyclerView;
//    RvAdapter rvAdapter;
//    List<String> rvList;

    List<String> rvList = new ArrayList<>();
    RvAdapter rvAdapter;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.e_activity_main);

        rvList = new ArrayList<>();
        rvList.add("Iron Man");
        rvList.add("The Incredible Hulk");
        rvList.add("Iron Man 2");
        rvList.add("Thor");
        rvList.add("Captain America: The First Avenger");
        rvList.add("The Avengers");
        rvList.add("Iron Man 3");
        rvList.add("Thor: The Dark World");
        rvList.add("Captain America: The Winter Soldier");
        rvList.add("Guardians of the Galaxy");
        rvList.add("Avengers: Age of Ultron");
        rvList.add("Ant-Man");
        rvList.add("Captain America: Civil War");
        rvList.add("Doctor Strange");
        rvList.add("Guardians of the Galaxy Vol. 2");
        rvList.add("Spider-Man: Homecoming");
        rvList.add("Thor: Ragnarok");
        rvList.add("Black Panther");
        rvList.add("Avengers: Infinity War");
        rvList.add("Ant-Man and the Wasp");
        rvList.add("Captain Marvel");
        rvList.add("Avengers: Endgame");
        rvList.add("Spider-Man: Far From Home");

        recyclerView = findViewById(R.id.recyclerView);
        rvAdapter = new RvAdapter(rvList);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(rvAdapter);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN | ItemTouchHelper.START | ItemTouchHelper.END, 0) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {

            int fromPosition = viewHolder.getAdapterPosition();
            int toPosition = target.getAdapterPosition();
            Collections.swap(rvList, fromPosition, toPosition);
            recyclerView.getAdapter().notifyItemMoved(fromPosition, toPosition);
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

        }
    };

}






