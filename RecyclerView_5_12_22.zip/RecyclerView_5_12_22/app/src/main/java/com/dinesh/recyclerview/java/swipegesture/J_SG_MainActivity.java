package com.dinesh.recyclerview.java.swipegesture;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dinesh.recyclerview.R;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;


public class J_SG_MainActivity extends AppCompatActivity {

    // creating a variable for recycler view,
    // array list and adapter class.
    private RecyclerView courseRV;
    private ArrayList<J_SG_RecyclerData> JSGRecyclerDataArrayList;
    private J_SG_RecyclerViewAdapter JSGRecyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.j_sg_activity_main);

        // initializing our variables.
        courseRV = findViewById(R.id.idRVCourse);

        // creating new array list.
        JSGRecyclerDataArrayList = new ArrayList<>();

        // in below line we are adding data to our array list.
        JSGRecyclerDataArrayList.add(new J_SG_RecyclerData("DSA Course", "DSA Self Paced Course"));
        JSGRecyclerDataArrayList.add(new J_SG_RecyclerData("C++ Course", "C++ Self Paced Course"));
        JSGRecyclerDataArrayList.add(new J_SG_RecyclerData("Java Course", "Java Self Paced Course"));
        JSGRecyclerDataArrayList.add(new J_SG_RecyclerData("Python Course", "Python Self Paced Course"));
        JSGRecyclerDataArrayList.add(new J_SG_RecyclerData("Fork CPP", "Fork CPP Self Paced Course"));
        JSGRecyclerDataArrayList.add(new J_SG_RecyclerData("Amazon SDE", "Amazon SDE Test Questions"));

        // initializing our adapter class with our array list and context.
        JSGRecyclerViewAdapter = new J_SG_RecyclerViewAdapter(JSGRecyclerDataArrayList, this);

        // below line is to set layout manager for our recycler view.
        LinearLayoutManager manager = new LinearLayoutManager(this);

        // setting layout manager for our recycler view.
        courseRV.setLayoutManager(manager);

        // below line is to set adapter
        // to our recycler view.
        courseRV.setAdapter(JSGRecyclerViewAdapter);
        // on below line we are creating a method to create item touch helper
        // method for adding swipe to delete functionality.
        // in this we are specifying drag direction and position to right
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                // this method is called
                // when the item is moved.
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // this method is called when we swipe our item to right direction.
                // on below line we are getting the item at a particular position.
                J_SG_RecyclerData deletedCourse = JSGRecyclerDataArrayList.get(viewHolder.getAdapterPosition());

                // below line is to get the position
                // of the item at that position.
                int position = viewHolder.getAdapterPosition();

                // this method is called when item is swiped.
                // below line is to remove item from our array list.
                JSGRecyclerDataArrayList.remove(viewHolder.getAdapterPosition());

                // below line is to notify our item is removed from adapter.
                JSGRecyclerViewAdapter.notifyItemRemoved(viewHolder.getAdapterPosition());

                // below line is to display our snackbar with action.
                Snackbar.make(courseRV, deletedCourse.getTitle(), Snackbar.LENGTH_LONG).setAction("Undo", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // adding on click listener to our action of snack bar.
                        // below line is to add our item to array list with a position.
                        JSGRecyclerDataArrayList.add(position, deletedCourse);

                        // below line is to notify item is
                        // added to our adapter class.
                        JSGRecyclerViewAdapter.notifyItemInserted(position);
                    }
                }).show();
            }
            // at last we are adding this
            // to our recycler view.
        }).attachToRecyclerView(courseRV);
    }
}