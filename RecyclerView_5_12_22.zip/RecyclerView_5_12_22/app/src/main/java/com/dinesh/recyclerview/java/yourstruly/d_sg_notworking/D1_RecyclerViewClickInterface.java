//package com.dinesh.recyclerview.java.yourstruly.d;
//
//public interface RecyclerViewClickInterface {
//    void onItemClick(int position);
//    void onLongItemClick(int position);
//}